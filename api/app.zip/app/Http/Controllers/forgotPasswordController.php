<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class forgotPasswordController extends Controller
{
    public function forgot_password(Request $request){
        dd($request->all());
    }
}
